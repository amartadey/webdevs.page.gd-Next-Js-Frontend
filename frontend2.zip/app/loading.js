const Loading = () => {
    return (
       <div style={{height: "100vh",display: "flex",flexDirection: "column",alignItems: "center",justifyContent: "center"}}>
            <img src="/img/loading.gif" />
        </div>
    );
};

export default Loading;